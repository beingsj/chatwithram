<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: 'Rubik', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
        }

        h2 {
            text-align: center;
            color: #333;
            font-size: 28px;
            margin-bottom: 20px;
        }

        form {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            background-color: #FFF;
            box-shadow: 0px 5px 23px 0px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }

        label {
            display: block;
            font-size: 16px;
            color: #333;
            margin-bottom: 8px;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            box-sizing: border-box;
            border: 1px solid #e1e1e1;
            border-radius: 3px;
            font-size: 16px;
        }

        input[type="submit"] {
            background-image: -moz-linear-gradient(122deg, #e54595 0%, #fd378e 100%);
            background-image: -webkit-linear-gradient(122deg, #e54595 0%, #fd378e 100%);
            background-image: -ms-linear-gradient(122deg, #e54595 0%, #fd378e 100%);
            background-image: linear-gradient(122deg, #e54595 0%, #fd378e 100%);
            box-shadow: 0px 9px 32px 0px rgba(0, 0, 0, 0.2);
            color: #FFF;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-image: linear-gradient(122deg, #fd378e 0%, #e54595 100%);
            box-shadow: 0px 9px 32px 0px rgba(0, 0, 0, 0.3);
        }

        .error-message {
            color: #e54595;
            font-size: 14px;
            margin-top: 10px;
        }

        p {
            text-align: center;
            margin-top: 20px;
            font-size: 16px;
            color: #333;
        }

        a {
            color: #e38cb7;
        }

        a:hover,
        a:focus {
            color: #d6619c;
        }
    </style>
</head>
<body>

    <h2 style="text-align: center; color: #333;">Login Form</h2>

    <form id="login-form" action="process-login.php" method="post">
        <label for="username">Username:</label>
        <input type="text" name="username" id="username" required>

        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required>

        <input type="submit" value="Login">
        <p class="error-message" id="login-error-message"></p>
    </form>

    <p style="text-align: center; margin-top: 20px;">Not registered? <a href="signup.php">Sign Up</a></p>

    <!-- Include your JavaScript validation script here if needed -->
    <script src="login_script.js"></script>

</body>
</html>
