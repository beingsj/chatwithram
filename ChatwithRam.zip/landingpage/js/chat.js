document.addEventListener("DOMContentLoaded", function () {
    let bottom = document.querySelector(".bottom");
    let input = document.querySelector("#txt");
    let sendbtn = document.querySelector(".uil-message");
    let ul = document.querySelector("#list_cont");
  
    // Function to start the conversation session
    function startConversation() {
      // Hit the API endpoint to start the conversation
      fetch("https://ram-ai.onrender.com/start")
        .then(response => response.json())
        .then(data => {
          // Display the initial thread in the conversation
          displayThread(data.thread_id);
          // Store the thread_id for subsequent requests
          window.threadId = data.thread_id;
        })
        .catch(error => {
          console.error("Error starting conversation:", error);
        });
    }
  
    // Function to send a message to the server and get the response
    function sendMessageAndGetResponse(message) {
      // Hit the API endpoint to send the message and get the response
      return fetch("https://ram-ai.onrender.com/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          thread_id: window.threadId, // Use the stored thread_id
          message: message,
        }),
      })
      .then(response => response.json())
      .catch(error => {
        console.error("Error sending message:", error);
      });
    }
  
    // Function to display a thread in the chat
    function displayThread(thread) {
      let li = document.createElement("li");
      li.className = "rchat";
      li.textContent = thread;
      ul.appendChild(li);
  
      // Scroll to the bottom
      $(".msgs_cont").scrollTop($(".msgs_cont")[0].scrollHeight);
    }
  
    // Function to handle user input and interaction with the server
    function handleUserInteraction() {
      if (
        input.value !== "" &&
        input.value !== null &&
        input.value.length > 0 &&
        input.value.trim() !== ""
      ) {
        sendbtn.style.background = "transparent";
  
        // Display user message
        let li = document.createElement("li");
        li.className = "schat";
        li.textContent = input.value;
        ul.appendChild(li);
  
        // Scroll to the bottom
        $(".msgs_cont").scrollTop($(".msgs_cont")[0].scrollHeight);
  
        // Send user message to the server and get the response
        sendMessageAndGetResponse(input.value)
          .then(response => {
            // Display the response from the server
            displayThread(response.thread_id);
          });
  
        input.value = "";
      }
    }
  
    // Start the conversation session when the page loads
    startConversation();
  
    // Add event listeners
    bottom.addEventListener("click", () => {
      input.focus();
    });
  
    input.addEventListener("input", () => {
      if (input.value.length > 0) {
        sendbtn.style.background = "#11ba91";
      } else {
        sendbtn.style.background = "transparent";
      }
    });
  
    sendbtn.addEventListener("click", handleUserInteraction);
  });
  