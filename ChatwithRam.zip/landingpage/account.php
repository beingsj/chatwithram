<?php
// Check if the user is logged in
session_start();


// Include necessary files and fetch user details from your database
require_once 'config.php'; // Include your database connection file
$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM users WHERE id = $user_id";
$result = mysqli_query($conn, $query);

// Display user details
if ($result && mysqli_num_rows($result) > 0) {
    $user = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Account</title>
</head>
<body>
    <h1>Welcome, <?php echo $user['username']; ?>!</h1>
    <p>Email: <?php echo $user['email']; ?></p>
    <!-- Display other user details as needed -->
</body>
</html>
<?php
} else {
    echo "Error fetching user details.";
}
?>
