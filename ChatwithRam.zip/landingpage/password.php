<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: 'Rubik', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
        }

        h2 {
            text-align: center;
            color: #333;
            font-size: 28px;
            margin-bottom: 20px;
        }

        form {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            background-color: #FFF;
            box-shadow: 0px 5px 23px 0px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }

        label {
            display: block;
            font-size: 16px;
            color: #333;
            margin-bottom: 8px;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            box-sizing: border-box;
            border: 1px solid #e1e1e1;
            border-radius: 3px;
            font-size: 16px;
        }

        input[type="submit"] {
            background-image: -moz-linear-gradient(122deg, #e54595 0%, #fd378e 100%);
            background-image: -webkit-linear-gradient(122deg, #e54595 0%, #fd378e 100%);
            background-image: -ms-linear-gradient(122deg, #e54595 0%, #fd378e 100%);
            background-image: linear-gradient(122deg, #e54595 0%, #fd378e 100%);
            box-shadow: 0px 9px 32px 0px rgba(0, 0, 0, 0.2);
            color: #FFF;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-image: linear-gradient(122deg, #fd378e 0%, #e54595 100%);
            box-shadow: 0px 9px 32px 0px rgba(0, 0, 0, 0.3);
        }

        .error-message {
            color: #e54595;
            font-size: 14px;
            margin-top: 10px;
        }

        p {
            text-align: center;
            margin-top: 20px;
            font-size: 16px;
            color: #333;
        }

        a {
            color: #e38cb7;
        }

        a:hover,
        a:focus {
            color: #d6619c;
        }
    </style>
</head>
<body>
<!-- Password reset form -->
<form method="post" action="reset_password.php">
    <h3>Reset Password</h3>
    <label for="new_password">New Password:</label>
    <input type="password" name="new_password" id="new_password" required>

    <label for="confirm_password">Confirm Password:</label>
    <input type="password" name="confirm_password" id="confirm_password" required>

    <button type="submit" name="reset_password">Reset Password</button>
</form>
<script src="script.js"></script>

</body>
</html>
