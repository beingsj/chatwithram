<?php
include('config.php'); // Include your database connection configuration

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

   

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT * FROM signup WHERE username = ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Error preparing statement: " . $conn->error);
    }

    $stmt->bind_param("s", $username);
    $stmt->execute();

    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if ($row && password_verify($password, $row['password'])) {
        echo "Login successful!";
        header("Location: account.php");
exit();


        
    } else {
        echo "Invalid username or password";

        // Debugging: Output received data
        echo "Received username: " . $username . "<br>";
        echo "Received password: " . $password . "<br>";

        // Debugging: Output database row
        print_r($row);
    }

    $stmt->close();
    $conn->close();
}
?>
