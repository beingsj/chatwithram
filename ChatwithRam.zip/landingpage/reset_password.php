<?php
session_start();
include 'db.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page if not logged in
    header("Location: login.php");
    exit();
}

// Get user ID from the session
$userId = $_SESSION['user_id'];

// Handle password reset
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset_password'])) {
    $newPassword = password_hash($_POST['new_password'], PASSWORD_DEFAULT);

    // Update user password in the database
    $updatePasswordSql = "UPDATE users SET password = '$newPassword' WHERE id = $userId";
    if ($conn->query($updatePasswordSql) === TRUE) {
        $_SESSION['success_message'] = "Password reset successful!";
        header("Location: account.php");
        exit();
    } else {
        // Handle the case where the password reset fails
        $_SESSION['error_message'] = "Error updating password: " . $conn->error;
        header("Location: account.php");
        exit();
    }
}

$conn->close();
?>
