<?php
// Include the configuration file
require_once 'config.php';

// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Validate and sanitize input
$new_username = $_POST['new_username'];
$new_email = $_POST['new_email'];

// Update details in the database
$user_id = $_SESSION['user_id'];
$query = "UPDATE signup SET username = ?, email = ? WHERE id = ?";
$stmt = $mysqli->prepare($query);
$stmt->bind_param("ssi", $new_username, $new_email, $user_id);
$stmt->execute();

// Close the prepared statement
$stmt->close();

// Redirect the user to the account page with a success message
header("Location: account.php?success=1");
exit();
?>
