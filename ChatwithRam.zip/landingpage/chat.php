<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="A powerful Chatbot Assistant: Get answers, solutions, and engage in meaningful conversations.">
  <meta name="keywords" content="chatbot, AI, answers, solutions, conversations, chatGPT">
  <meta name="author" content="TH3_BULL">
  <meta name="robots" content="index, follow">
  <meta name="og:title" property="og:title" content="ChatGPT Clone">
  <meta name="og:description" property="og:description" content="A powerful Chatbot Assistant: Get answers, solutions, and engage in meaningful conversations.">
  <meta name="og:image" property="og:image" content="https://i.postimg.cc/rw8f7Vkj/OIG.jpg">
  <meta name="og:url" property="og:url" content="https://github.com/devnasfam/chatGPT-Clone">
  <meta name="og:type" property="og:type" content="website">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <script src="https://kit.fontawesome.com/d3c9fc67a3.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
  <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/solid.css">
  <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/thinline.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <link rel="stylesheet" href="style.css">
  <script src="app.js"></script>
  <title>Chatbot</title>
  <style>
    * {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Nunito', sans-serif;
}

body {
  overflow: none;
}

main {
  width: 100vw;
  height: 100%;
  position: absolute;
  background: #FFFF;
  overflow: hidden;
}

main .topper {
  width: 100%;
  height: auto;
    background: #ff6200;

  padding: 10px;
  position: sticky;
  z-index: 1;
  top: 0;
  right: 0;
  display: flex;
  align-items: center;
  justify-content: start;
}

main .topper .icon {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  
  /* You can replace this with the actual image */
  background:  url('https://i.pinimg.com/736x/1a/2e/04/1a2e048173d95fb90b447969ec65c622.jpg');
  background-size: cover;
  margin-left: 15px;
}

main .topper .name {
  color: #fff;
  font-weight: bolder;
  margin-left: 15px;
  font-size: 18px;
  letter-spacing: 2px;
}

main .bottom {
  width: 100%;
  height: auto;
  background: #ff6200;
  position: fixed;
  z-index: 1;
  bottom: 0;
  right: 0;
  padding: 10px;
  padding-bottom: 25px;
  display: flex;
  align-items: center;
  justify-content: center;
}

main .bottom #input {
  width: 95%;
  height: auto;
  background: white;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 5px;
}

main .bottom #input input {
  width: 90%;
  padding: 7px;
  border: none;
  outline: none;
  background: transparent;
  color: #ff6200;
  font-size: 16px;
}

main .bottom #input input::placeholder {
  color: #ff6200;
}

main .bottom #input button {
  padding: 5px 10px;
  margin: 0 5px;
  font-size: 20px;
  border-radius: 10px;
  color: #fff;
  transition: 0.2s;
  outline: none;
  border: none;
  background: transparent;
}

main .bottom #input button:active {
  transform: scale(0.96);
  background: #13d2a3;
  opacity: 0.4;
}

main .bottom::after {
  content: 'COPYRIGHT © 2024. ALL RIGHTS RESERVED.';
  position: absolute;
  width: 100%;
  bottom: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 13px;
  color: #b3b3b3;
}

main .msgs_cont {
  width: 100%;
  height: calc(100vh - 155px);
  overflow: auto;
  padding: 10px;
  padding-bottom: 15px;
  scroll-behavior: smooth;
}

main .msgs_cont ul {
  width: 100%;
  padding: 5px;
}

main .msgs_cont li {
  padding: 10px;
  max-width: 70%;
  margin: 10px 0;
  background: linear-gradient(15deg, #13547a 0%, #80d0c7 100%);
  color: #fff;
  list-style-type: none;
  border-radius: 10px;
  color: #f2f2f2;
  word-wrap: break-word;
  overflow: hidden;
  position: relative;
}

main .msgs_cont .schat {
  float: right;
  clear: both;
  margin-bottom: 5px;
  border-bottom-right-radius: 20px;
}

main .msgs_cont .rchat {
  float: left;
  clear: both;
  margin-bottom: 5px;
  background: linear-gradient(to top right, #11ba91, #0a6e55);
  padding-left: 12px;
  border-bottom-left-radius: 20px;
}

.typing-animation {
  display: inline-block;
}

.dot {
  display: inline-block;
  width: 9px;
  height: 9px;
  background: #cccccc;
  border-radius: 50%;
  margin-right: 5px;
  opacity: 0;
  animation: typing-dot 1s infinite;
}

.dot:nth-child(2) {
  animation-delay: 0.2s;
}

.dot:nth-child(3) {
  animation-delay: 0.4s;
}

@keyframes typing-dot {
  0%, 20% {
    opacity: 0;
    transform: translateY(0);
  }

  50% {
    opacity: 1;
    transform: translateY(-7px);
  }

  80%, 100% {
    opacity: 0;
    transform: translateY(0);
  }
}

  </style>
</head>

<body>
  <main>
    <div class="topper">
      <div class="icon"></div>
      <div class="name">JAI SHREE RAM</div>
    </div>
    <div class="msgs_cont">
      <ul id="list_cont">
        <li class="rchat">Hello!, How are you today?</li>
      </ul>
    </div>
    <div class="bottom">
      <div id="input">
        <input type="text" id="txt" placeholder="Send a message">
        <button class="uil uil-message"></button>
      </div>
    </div>
  </main>
</body>

</html>
